<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;
use Core\Main;

class PickPocketEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "PickPocket";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_UNCOMMON;

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            if ($entity instanceof Player) {
				$ebal = Main::getInstance()->getmoney($entity);
				$chance = mt_rand(0, 500);
				if((($ebal) - ($chance)) < 0){
					$ename = $entity->getName();
                    $player->sendMessage("$ename is broke he doesnt have any money");
					$pn = $player->getName();
                $entity->sendMessage("$pn Tried to steal money from your pocket but you are broke");	
              
                    } else {
						Main::getInstance()->addbal($player, $chance);
						Main::getInstance()->subtractbal($entity, $chance);
						$pn = $player->getName();
                $entity->sendMessage("$pn Stole $$chance From you");
				$player->sendMessage("You stole $$chance from $ename");
				
					}
            }
        }
    }
}