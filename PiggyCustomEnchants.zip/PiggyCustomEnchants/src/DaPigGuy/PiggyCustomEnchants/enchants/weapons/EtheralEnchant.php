<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\weapons;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Event;
use pocketmine\entity\Effect;
use pocketmine\entity\Living;
use pocketmine\entity\EffectInstance;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class EtheralEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Etheral";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_SIMPLE;
    /** @var int */
    public $maxLevel = 1;
    /** @var int */
    public $cooldownDuration = 5;

    public function getDefaultExtraData(): array
    {
        return ["Haste" => 0.5];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
				$en = $event->getEntity();
		 if($en instanceof Living){
            if ($damager instanceof Player) {
                    $damager->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 60 * $level, 1 * $level));
        
            }
        }
	  }
    }
}