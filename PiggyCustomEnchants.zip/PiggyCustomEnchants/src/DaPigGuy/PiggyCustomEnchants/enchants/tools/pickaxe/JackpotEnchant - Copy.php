<?php

declare(strict_types=1);

namespace DaPigGuy\PiggyCustomEnchants\enchants\tools\pickaxe;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchant;
use DaPigGuy\PiggyCustomEnchants\enchants\ReactiveEnchantment;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Event;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\Player;

class JackpotEnchant extends ReactiveEnchantment
{
    /** @var string */
    public $name = "Jackpot";
    /** @var int */
    public $rarity = CustomEnchant::RARITY_MYTHIC;

    /** @var int */
    public $itemType = CustomEnchant::ITEM_TYPE_PICKAXE;


    public function getReagent(): array
    {
        return [BlockBreakEvent::class];
    }

    public function react(Player $player, Item $item, Inventory $inventory, int $slot, Event $event, int $level, int $stack): void
    {
        if ($event instanceof BlockBreakEvent) {
			if ($player instanceof Player){
				$chances = rand(0, 100);
			}
        }
    }

    public function getPriority(): int
    {
        return 3;
    }
}
